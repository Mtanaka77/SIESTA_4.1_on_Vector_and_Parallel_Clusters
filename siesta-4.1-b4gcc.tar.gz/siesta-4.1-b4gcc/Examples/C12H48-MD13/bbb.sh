#!/bin/bash
# % sh bbb.sh

echo hello world

export OMP_NUM_THREADS=6
mpiexec -n 1 ~/siesta-4.1-b4gcc/Obj3/siesta c12h48.fdf > c12h48.out &
 
exit 0

