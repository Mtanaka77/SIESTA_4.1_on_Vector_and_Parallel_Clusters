#!/bin/bash
#  sh aaa.sh  for the run

echo hello world

export OMP_NUM_THREADS=1
mpiexec -n 6 ~/siesta-4.1-b4gcc/Obj1/siesta c12h48.fdf > c12h48.out &

#/opt/mpich-4.0.2/bin/mpirun -np 6 ~/siesta-4.1-b4gcc/Obj11/siesta c12h48.fdf > c12h48.out &
 
exit 0

