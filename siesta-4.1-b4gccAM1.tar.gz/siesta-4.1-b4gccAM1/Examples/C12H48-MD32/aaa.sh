#!/bin/bash
# % sh bbb.sh

echo hello world

export OMP_NUM_THREADS=1
mpiexec -n 6 /home/mtanaka/siesta-4.1-b4gcc0/Obj1/siesta c12h48.fdf > c12h48.out &
 
exit 0
