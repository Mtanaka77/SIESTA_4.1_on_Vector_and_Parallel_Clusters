#!/bin/bash
#------- qsub option -----------
#PBS -q gpu-b
#PBS --group=21275
#PBS -T intmpi
#PBS -l elapstim_req=10:00:00  # max 10 hours
#PBS -l coresz_prc=0
#PBS -b 1        # 96 core per 2 nodes
#  PBS -b 2        # 96 core per 2 nodes
#
#  do: module load intel-lx/2020update0
#  do: make by 2020update0 
#    then logout 
#    login, and run by using 2017update8
#
#PBS -v NQSV_MPI_VER=2017update8
#  PBS -v NQSV_MPI_VER=2020update0
#PBS -N siesta

export EXEC=siesta
module load intel-lx/$NQSV_MPI_VER

cd ${PBS_O_WORKDIR}

mpirun -machinefile ${PBS_NODEFILE} -n 48 -perhost 1 ~/siesta-4.1-b4-LX/Obj/siesta < ./c96h384.fdf > c96h384.out

